ROOM & COMPANY — Windows x64

Extract this entire ZIP into a new folder and run RoomAndCompany.exe.
This is a standalone, non-explicit room sandbox. You do not need Wife's Bedroom
or Godot installed to play.

Choose your companion, outfit, pose, room palette, and lighting.
Chat, wave, share tea, or click your companion to wave.
Toggle music and try different poses. Your settings save automatically.
F11: fullscreen. Escape: normal window. The 4K button opens a 3840x2160 window.

CUSTOM CHARACTERS
Use Import your character to load a PNG, or select a character.json pack.
PNG frames can be 3840x2160 or 4096x4096. Use separate files, not a horizontal strip.
Each frame should have the same canvas dimensions and matching alignment.
The included custom-character-example.json is a template; add your own images.
Imported artwork keeps its original colors. It uses its own poses and outfits.
Only two frame textures are cached; large PNG animations may stutter while decoding.
Keep the imported folder in place to restore it the next time you open the game.

PROJECT SOURCE AND COMPLETE INSTRUCTIONS
https://github.com/walpbear/Testing/tree/main/room-sandbox

TESTING
The actual scene passed 18 headless functional checks and 19 graphics-enabled checks,
including real 4096x4096 PNG decoding/rendering, pose switching, saving, invalid-pack
handling and texture-cache limits. The Linux export was launched successfully.
Windows x64 export succeeded, but the Windows executable has not been run here.
This is a small playable sandbox, not a full story campaign.

ENGINE
Godot 4.6.3. Engine and dependency license notices are included in this download.
